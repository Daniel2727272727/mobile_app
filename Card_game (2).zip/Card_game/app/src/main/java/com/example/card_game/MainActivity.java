package com.example.card_game;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.BreakIterator;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView iv_card_left, iv_card_right;
    TextView tv_score_left, tv_score_right;
    TextView tv_text1;
    Button b_deal;

    Random r;

    int leftScore = 0, rightScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv_card_left = (ImageView) findViewById(R.id.iv_card_left);
        iv_card_right = (ImageView) findViewById(R.id.iv_card_right);
        tv_score_left = (TextView) findViewById(R.id.tv_score_left);
        tv_score_right = (TextView) findViewById(R.id.tv_score_right);
        b_deal = (Button) findViewById(R.id.b_deal);
        tv_text1 = (TextView) findViewById(R.id.tv_text);

        r = new Random();

        b_deal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //генерация присваивания чисел картам
                int leftCard = r.nextInt(13) + 2;
                int rightCard = r.nextInt(13) + 2;
                //показ изображения карты
                int leftImage = getResources().getIdentifier("card" + leftCard, "drawable", getPackageName());
                iv_card_left.setImageResource(leftImage);
                //показ изображения карты
                int rightImage = getResources().getIdentifier("card" + rightCard, "drawable", getPackageName());
                iv_card_right.setImageResource(rightImage);
                //сравнение карт и добавляем счетчик
                if (leftCard > rightCard) {
                    leftScore++;
                    tv_score_left.setText(String.valueOf(leftScore));
                }    else if (leftCard < rightCard) {
                    rightScore++;
                    tv_score_right.setText(String.valueOf(rightScore));
                }    else {
                    Toast.makeText(MainActivity.this, "WAR", Toast.LENGTH_SHORT).show();
                }

                if (leftScore > 9) {
                    tv_text1.setText("WIN 1 player");
                    leftScore = 0;
                    rightScore = 0;

                } else if (rightScore > 9) {
                    tv_text1.setText("WIN 2 player");
                    rightScore = 0;
                    leftScore = 0;
                }

            }
        });

    }
}